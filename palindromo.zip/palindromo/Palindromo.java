public class Palindromo {
    public boolean esPalindromo(String palabra) {                               // funcion para verificar que una palabra es palindromo
        if (palabra.length() <= 1) {                                            //esto reconoce cuantos caracteres tiene la palabra
            return true;
        }
        if (palabra.charAt(0) != palabra.charAt(palabra.length() - 1)) {        // esto comprueba que la primera y ultima letra sean iguales
            return false;
        }
        return esPalindromo(palabra.substring(1, palabra.length() - 1));        // para llamar recursivamente a la función con la palabra sin el primer y último carácter
    }
}

