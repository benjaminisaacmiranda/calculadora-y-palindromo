import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Por favor ingrese una palabra para verificar si es palindromo: ");
        String palabra = scanner.nextLine();
        
        Palindromo palindromo = new Palindromo();
        
        if (palindromo.esPalindromo(palabra)) {
            System.out.println(palabra + " es un palindromo");
        } else {
            System.out.println(palabra + " no es un palindromo");
        }
        
        scanner.close();
    }
}
