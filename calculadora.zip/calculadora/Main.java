import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numero1, numero2;

        System.out.println("--------------Bienvenida sea usted a la super ultra calculadora casio digital 90000-----------------");

        do {
            System.out.println("\nPor favor ingrese el primer número:");
            numero1 = scanner.nextInt();
            System.out.println("Ahora ingrese el segundo número:");
            numero2 = scanner.nextInt();
            if (numero1 < 0 || numero2 < 0) {
                System.out.println("Por favor ingrese números enteros positivos.");
            }
        } while (numero1 < 0 || numero2 < 0);
        Calculadora calculadora = new Calculadora(numero1, numero2);
        while (true) {
            System.out.println("\nMenú:");
            System.out.println("1.- Sumar los números");
            System.out.println("2.- Restar los números");
            System.out.println("3.- Multiplicar los números");
            System.out.println("4.- Dividir los números");
            System.out.println("5. Salir de la super ultra calculadora casio digital 90000");
            System.out.println("Elija la operación que desea que realice la super ultra calculadora casio digital 90000:");
            int opcion = scanner.nextInt();
            switch (opcion) {
                case 1:
                    System.out.println("La suma de estos dos números es: " + calculadora.suma());
                    break;
                case 2:
                    System.out.println(" La resta de estos dos números es: " + calculadora.resta());
                    break;
                case 3:
                    System.out.println("El producto de estos dos números es: " + calculadora.multiplicacion());
                    break;
                case 4:
                    try {
                        System.out.println("El cociente de estos dos números es: " + calculadora.division());
                    } catch (ArithmeticException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 5:
                    System.out.println("-------------------Gracias por ocupar la super ultra calculadora casio digital 90000 :)----------------------");
                    System.exit(0);
                default:
                    System.out.println("------------------Por favor ingrese una de las 5 opciones.------------------");
            }
        }
    }
}